import os
import time
import logging
from pathlib import Path
from datetime import datetime, timedelta
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
from dotenv import load_dotenv
from igonore_firefox_updates import dismiss_firefox_update_dialog

# Load credentials from .env file
load_dotenv("credentials.env")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(levelname)s] %(asctime)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

ERP_USERNAME = os.environ.get('ERP_USERNAME')
ERP_PASSWORD = os.environ.get('ERP_PASSWORD')
ERP_URL = os.environ.get('ERP_URL')

if not ERP_USERNAME or not ERP_PASSWORD:
    logging.error("ERP_USERNAME and ERP_PASSWORD must be set in credentials.env.")
    exit(1)

DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), 'Input_Data/CREDIT_SCORE_DECISION_data'))
if not os.path.exists(DATA_DIR):
    os.makedirs(DATA_DIR)


def setup_firefox_driver():
    options = Options()
    options.set_preference("webdriver_accept_untrusted_certs", True)
    options.set_preference("acceptInsecureCerts", True)
    options.set_preference("browser.download.folderList", 2)
    options.set_preference("browser.download.dir", DATA_DIR)
    options.set_preference("browser.helperApps.neverAsk.saveToDisk",
        "application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/octet-stream")
    options.set_preference("pdfjs.disabled", True)
    # options.headless = True
    driver = webdriver.Firefox(options=options)
    driver.maximize_window()
    return driver


def login(driver, username, password):
    logging.info("Navigating to login page")
    driver.get(ERP_URL)
    try:
        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "txtusername")))
        driver.find_element(By.ID, "txtusername").send_keys(username)
        driver.find_element(By.ID, "txtpassword").send_keys(password)
        driver.find_element(By.CLASS_NAME, "login100-form-btn").click()
        logging.info("Login submitted")
    except Exception as e:
        logging.error(f"Login failed: {e}")
        raise


def expand_menu(driver, menu_text):
    logging.info(f"Expanding menu: {menu_text}")
    dropdown_buttons = driver.find_elements(By.CLASS_NAME, "dropdown-btn")
    for btn in dropdown_buttons:
        try:
            span = btn.find_element(By.TAG_NAME, "span")
            if span.text.strip() == menu_text:
                driver.execute_script("arguments[0].click();", btn)
                time.sleep(1)
                return True
        except Exception:
            continue
    logging.warning(f"Menu '{menu_text}' not found.")
    return False


def click_reports(driver):
    logging.info("Clicking 'Reporting Management' link")
    try:
        reporting_link = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//a[contains(text(), 'Reporting Management')]"))
        )
        driver.execute_script("arguments[0].click();", reporting_link)
        logging.info("Navigated to Reports.")
    except TimeoutException:
        logging.error("'Reporting Management' link not found or not clickable.")
        raise


def switch_to_module_iframe(driver):
    time.sleep(2)
    iframes = driver.find_elements(By.TAG_NAME, "iframe")
    logging.info(f"Found {len(iframes)} iframe(s)")
    for index, iframe in enumerate(iframes):
        try:
            driver.switch_to.frame(iframe)
            driver.find_element(By.ID, "search_module")
            driver.find_element(By.ID, "search_report")
            logging.info(f"Found 'search_module' dropdown inside iframe index {index}")
            return True
        except NoSuchElementException:
            driver.switch_to.default_content()
    try:
        driver.find_element(By.ID, "search_module")
        logging.info("Found 'search_module' dropdown on main page")
        return True
    except NoSuchElementException:
        logging.error("Could not find 'search_module' dropdown in any iframe or main page.")
        return False


def select_search_module(driver, module_name):
    try:
        select = Select(driver.find_element(By.ID, "search_module"))
        select.select_by_visible_text(module_name)
        logging.info(f"Selected '{module_name}' from dropdown.")
    except Exception as e:
        logging.error(f"Dropdown selection failed: {e}")
        raise


def switch_to_report_iframe(driver):
    time.sleep(2)
    iframes = driver.find_elements(By.TAG_NAME, "iframe")
    logging.info(f"Found {len(iframes)} iframe(s)")
    for index, iframe in enumerate(iframes):
        try:
            driver.switch_to.frame(iframe)
            driver.find_element(By.ID, "search_report")
            logging.info(f"Found 'search_report' dropdown inside iframe index {index}")
            return True
        except NoSuchElementException:
            driver.switch_to.default_content()
    try:
        driver.find_element(By.ID, "search_report")
        logging.info("Found 'search_report' dropdown on main page")
        return True
    except NoSuchElementException:
        logging.error("Could not find 'search_report' dropdown in any iframe or main page.")
        return False


def select_report_type(driver, report_name):
    try:
        select = Select(driver.find_element(By.ID, "search_report"))
        select.select_by_visible_text(report_name)
        logging.info(f"Selected '{report_name}' from dropdown.")
    except Exception as e:
        logging.error(f"Dropdown selection failed: {e}")
        raise

def get_date_range(previous_month=False):
    to_date = datetime.now() - timedelta(days=1)
    
    from_date = (to_date.replace(day=1)).strftime("%Y-%m-%d")
    to_date = to_date.strftime("%Y-%m-%d")
    
    if previous_month:
        today = datetime.now()
        first_day_of_current_month = today.replace(day=1)
        last_day_of_previous_month = first_day_of_current_month - timedelta(days=1)
        first_day_of_previous_month = last_day_of_previous_month.replace(day=1)
        
        from_date = first_day_of_previous_month.strftime("%Y-%m-%d")
        to_date = last_day_of_previous_month.strftime("%Y-%m-%d")    
    return from_date, to_date


def set_from_date(driver, date_str):
    try:
        from_date_input = driver.find_element(By.ID, "search_from_date")
        driver.execute_script("arguments[0].value = arguments[1];", from_date_input, date_str)
        logging.info(f"Set 'search_from_date' to {date_str}")
    except Exception as e:
        logging.error(f"Failed to set 'search_from_date': {e}")
        raise


def set_to_date(driver, date_str):
    try:
        to_date_input = driver.find_element(By.ID, "search_to_date")
        driver.execute_script("arguments[0].value = arguments[1];", to_date_input, date_str)
        logging.info(f"Set 'search_to_date' to {date_str}")
    except Exception as e:
        logging.error(f"Failed to set 'search_to_date': {e}")
        raise


def export_to_excel(driver):
    try:
        export_btn = driver.find_element(By.ID, "excel_btn")
        
        # Check if button is disabled
        is_disabled = export_btn.get_attribute("disabled")
        if is_disabled:
            logging.warning("Excel button is disabled. Waiting for it to be enabled...")
            
            # Wait for button to be enabled (up to 30 seconds)
            WebDriverWait(driver, 30).until(
                lambda d: d.find_element(By.ID, "excel_btn").get_attribute("disabled") is None
            )
            logging.info("Excel button is now enabled")
            
            # Re-find the button after it's enabled
            export_btn = driver.find_element(By.ID, "excel_btn")
        
        # Click the export button
        driver.execute_script("arguments[0].click();", export_btn)
        logging.info("Clicked 'Excel' export button.")

        # Wait for download to start - try multiple approaches
        logging.info("Waiting for download to start...")
        
        # Try to find and handle confirmation modal if it exists
        try:
            # Wait a short time for modal to appear
            WebDriverWait(driver, 10).until(
                EC.visibility_of_element_located((By.CLASS_NAME, "ajs-button"))
            )
            
            # Click 'Yes' button if modal appears
            yes_button = driver.find_element(By.XPATH, "//button[contains(@class, 'ajs-ok')]")
            driver.execute_script("arguments[0].click();", yes_button)
            logging.info("Clicked 'Yes' to confirm export.")
        except TimeoutException:
            logging.info("No confirmation modal found - download may have started directly")
        
        # Wait for download to complete
        time.sleep(10)
        logging.info("Export completed - file should be downloaded to data directory")
        
    except Exception as e:
        logging.error(f"Failed to export: {e}")
        raise

def wait_for_download(download_dir, before, timeout=600, poll_interval=5):
    """
    Waits for a NEW .xlsx file (one not already present in `before`) to finish
    downloading, then returns its full path. Raises Exception on timeout.

    `before` must be a snapshot of the directory taken BEFORE the download is
    triggered, so a previously-downloaded file is never mistaken for the new
    one. Firefox writes to a temporary "<name>.part" file and renames it to
    ".xlsx" only once complete; a size check confirms the file is fully
    written before returning.
    """
    elapsed = 0
    last_size = -1
    while elapsed < timeout:
        after = set(os.listdir(download_dir))
        new_xlsx = sorted(f for f in (after - before) if f.endswith('.xlsx'))
        if new_xlsx:
            file_path = os.path.join(download_dir, new_xlsx[0])
            size = os.path.getsize(file_path)
            if size > 0 and size == last_size:
                return file_path
            last_size = size
        time.sleep(poll_interval)
        elapsed += poll_interval
    raise Exception("Download did not complete in time.")


def main():
    driver = setup_firefox_driver()
    try:
        login(driver, ERP_USERNAME, ERP_PASSWORD)
        
        # ---- Ignore Firefox Updates ----
        update_img = r"C:\Users\sachintha.fernando\Documents\Report_Automation\3W_Auto_Finance_Report\img\Update_Message.png"
        dismiss_img = r"C:\Users\sachintha.fernando\Documents\Report_Automation\3W_Auto_Finance_Report\img\Dismiss_Button.png"
        dismiss_firefox_update_dialog(update_img, dismiss_img, timeout=15, confidence=0.8)

        WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, "dropdown-btn")))
        time.sleep(2)
        expand_menu(driver, "Control Panel")
        expand_menu(driver, "Report")
        click_reports(driver)
        if not switch_to_module_iframe(driver):
            raise Exception("Could not find 'Search_Module' dropdown.")
        select_search_module(driver, "Help Desk")
        if not switch_to_report_iframe(driver):
            raise Exception("Could not find 'Search_Report' dropdown.")
        select_report_type(driver, "Credit Score Decision Report")

        # yesterday = (datetime.now() - timedelta(days=0)).strftime("%Y-%m-%d")
        from_date, to_date = get_date_range(previous_month=False)
        set_from_date(driver, from_date)
        set_to_date(driver, to_date)
        
        before_files = set(os.listdir(DATA_DIR))
        export_to_excel(driver)
        downloaded_file = wait_for_download(DATA_DIR, before_files, timeout=600)
        
        # # Rename the file
        # today = datetime.now().strftime("%Y-%m-%d")
        # latest_file = Path(downloaded_file)
        # renamed_path = latest_file.parent / latest_file.with_stem(f"CREDIT_SCORE_DECISION_{today}").name
        # latest_file.rename(renamed_path)
        
        # Rename the file
        today = datetime.now().strftime("%Y-%m-%d")
        latest_file = Path(downloaded_file)
        renamed_path = latest_file.parent / f"CREDIT_SCORE_DECISION_{today}{latest_file.suffix}"
        latest_file.replace(renamed_path)

        
        logging.info(f"[SUCCESS] Report export completed. File will be saved in: {DATA_DIR}")
        time.sleep(5)
    except Exception as e:
        logging.error(f"[ERROR] {str(e)}")
    finally:
        driver.quit()


if __name__ == "__main__":
    main()
