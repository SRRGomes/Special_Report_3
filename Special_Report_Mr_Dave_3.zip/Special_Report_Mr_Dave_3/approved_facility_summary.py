"""
Approved Facility (AF / 3W / 2W) Analysis — data prep, decision matching, PDF + Excel.

Covers steps 2-7, 11 and 12 of workflow_v1.txt:
  * read Approval Report HO + Branch (headers/footers skipped), add APPR_SOURCE,
    concatenate, keep STAT_CON = ACTIVE
  * credit decision: Credit Score Decision Report (FACNO -> AI_DECISION) first,
    then RBP Security Approved (FACILITY_NO -> CR_GRADE); DECISION_MATCHED_SRC
  * Product Category (Auto Finance / 3W / 2W / Other), Product Segment,
    Customer Type (Existing / New)
  * PDF + Excel (one sheet per product) into reports/<YYYY-MM-DD>/,
    used downloads + Preprocessed_All / Preprocessed_AF_3W_2W into reports/<YYYY-MM-DD>/data/

    python approved_facility_summary.py --mode cumulative
    python approved_facility_summary.py --mode past-n-months --n-months 3
"""
import os
import sys
import re
import glob
import shutil
import argparse
import logging
import time
from pathlib import Path
from datetime import datetime

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import landscape, letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (CondPageBreak, Paragraph, SimpleDocTemplate, Spacer,
                                Table, TableStyle)

from report_period import MODES, get_period, period_label, period_tag
from log_config import setup_logging

# Module logger; handlers (console + daily log file) are set up in main()
# so importing REPORT_NAME from here does not start a log session.
log = logging.getLogger("approved_facility_summary")

# ============================================================
# REPORT NAME  (Report Title, Email Subject and output file names)
# ============================================================
REPORT_NAME = "Approved Facility_(AF_3W_2W)_Analysis"

# ============================================================
# CONFIGURATION
# ============================================================
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"             # downloaders save here (staging)
REPORTS_DIR = BASE_DIR / "reports"       # reports/<YYYY-MM-DD>/ and .../data/

# key -> (staging sub-folder, file-name prefix)
SOURCES = {
    "HO":           ("APPROVAL_REPORT_data_HO",     "APPROVAL_REPORT_HO"),
    "BRANCH":       ("APPROVAL_REPORT_data_BRANCH", "APPROVAL_REPORT_BRANCH"),
    "CREDIT_SCORE": ("CREDIT_SCORE_DECISION_data",  "CREDIT_SCORE_DECISION"),
    "RBP":          ("RBP_SECURITY_APPROVED_data",  "RBP_SECURITY_APPROVED"),
}
APPR_SOURCE = {"HO": "HO", "BRANCH": "Branch"}

# ---- Column names, after normalisation (upper case, spaces -> '_') ----
KEY_COL = "NEW_CONNO"                   # facility no. in the Approval Report
STATUS_COL = "STAT_CON"                 # 'STAT CON'
ACTIVE_VALUE = "ACTIVE"
AMOUNT_COL = "LEASE_AMOUNT"             # 'LEASE AMOUNT'
RATE_COL = "INT_RATE"                   # 'INT RATE'
CONEX_COL = "CONEX_DATE"                # disbursement date
# First column found is used as the customer identifier / closure date
CUSTOMER_ID_CANDIDATES = ["NIC_NO", "NIC", "CUS_ID", "CUSTOMER_ID", "CLIENT_NIC", "CUSTOMER_CODE"]
CLOSURE_CANDIDATES = ["CLOSURE_DATE", "CLOSED_DATE", "CLOSE_DATE"]
DATE_DAYFIRST = False                   # text dates: False = MM-DD-YYYY (Oracle BI prompt format)

CS_KEY, CS_DECISION = "FACNO", "AI_DECISION"              # Credit Score Decision Report
RBP_KEY, RBP_DECISION = "FACILITY_NO", "CR_GRADE"         # RBP Security Approved

# ---- Decision mapping ----
DECISION_ORDER = ["Green", "Yellow", "Red", "Manual"]
UNMATCHED_DECISION = "Manual"
# Exact raw value (case-insensitive) -> decision. Checked before the keywords below.
CS_DECISION_MAP = {
    # "APPROVE": "Green",
}
RBP_DECISION_MAP = {
    # "A": "Green", "B": "Yellow", "C": "Red",
}
# Whole-word keywords in the raw value (so 'REFERRED' does not match RED)
DECISION_KEYWORDS = [
    (re.compile(r"\bGREEN\b"), "Green"),
    (re.compile(r"\b(YELLOW|AMBER)\b"), "Yellow"),
    (re.compile(r"\bRED\b"), "Red"),
    (re.compile(r"\bMANUAL\b"), "Manual"),
]

SRC_CS = "Credit Score Decision Report"
SRC_RBP = "RBP Security Approved Report"
SRC_BOTH = "Both"
SRC_NONE = "None"
SRC_ORDER = [SRC_CS, SRC_RBP, SRC_BOTH, SRC_NONE]

# ---- Customer type ----
EXISTING_LOOKBACK_MONTHS = 3
CUSTOMER_TYPES = ["Existing Customers", "New Customers"]

# ---- Products / segments ----
PRODUCTS = ["Auto Finance", "3W", "2W"]
SEGMENT_ORDER = ["HP/Lease", "Smart Draft", "Enhancement", "Pledge Loan", "Other"]
# Segment rows always shown (summary.xlsx); any other segment is added only when it has data
TEMPLATE_SEGMENTS = {
    ("Auto Finance", "Existing Customers"): ["HP/Lease", "Smart Draft", "Enhancement", "Pledge Loan"],
    ("3W", "Existing Customers"): ["HP/Lease", "Enhancement", "Pledge Loan"],
    ("2W", "Existing Customers"): ["HP/Lease", "Enhancement", "Pledge Loan"],
}
DEFAULT_TEMPLATE_SEGMENTS = ["HP/Lease"]              # New Customers
SEGMENT_DISPLAY = {"Enhancement": "Enhancements", "Pledge Loan": "Pledge loans"}
HP_LEASE_DISPLAY = {"Existing Customers": "New financing (Lease/HP)",
                    "New Customers": "Lease/HP"}

SMART_DRAFT_KEYS = [
    "int only", "intonly", "int-only", "interest only", "profit only",
    "intr only", "intrs only",
    "smart draft", "smart draf", "smart drft", "smrt draft", "smrt draf", "smrt drft",
]
# Whole words only: as substrings 'en' / 'enh' would hit ordinary words
ENHANCEMENT_RE = re.compile(
    r"\b(enhancement|enhancmnt|enhancemnt|enhncmnt|enhc|enhn|enh|en)\b", re.IGNORECASE)

# ------------------------------------------------------------
# STYLING (same as the Initiated Facility Details Report)
# ------------------------------------------------------------
PAGE_SIZE = landscape(letter)
PAGE_MARGIN = 0.4 * inch
CONTENT_WIDTH = PAGE_SIZE[0] - 2 * PAGE_MARGIN
FRAME_HEIGHT = PAGE_SIZE[1] - 2 * PAGE_MARGIN - 12

HEADER_BLUE = colors.HexColor('#4472C4')
SUBHDR_BLUE = colors.HexColor('#8EAADB')
TOTAL_FILL = colors.HexColor('#BDD7EE')
LABEL_FILL = colors.HexColor('#EAF0FA')
SUBTOTAL_FILL = colors.HexColor('#DEEAF6')
GRID_COLOR = colors.HexColor('#2F5496')
TITLE_NAVY = colors.HexColor('#1F3864')
TABLE_TITLE_BLUE = colors.HexColor('#2E4C7E')
DECISION_TINT = {"Green": '#E2EFDA', "Yellow": '#FFF2CC', "Red": '#FCE4D6', "Manual": '#EDEDED'}

# ============================================================
# HELPERS
# ============================================================

def _normalize(value):
    if pd.isna(value):
        return ""
    return " ".join(str(value).replace("_", " ").casefold().split())


def _key(series):
    """Clean string key for facility / customer matching ('12345.0', ' 123v ' -> '12345', '123V')."""
    key = series.astype(str).str.strip().str.upper().str.replace(r"\s+", "", regex=True)
    key = key.str.replace(r"\.0$", "", regex=True)
    return key.where(~key.isin(["", "NAN", "NONE", "NAT", "<NA>"]))


def to_number(series):
    cleaned = series.astype(str).str.replace(",", "", regex=False).str.strip()
    return pd.to_numeric(cleaned, errors="coerce").fillna(0).astype(float)


def to_date(series):
    if pd.api.types.is_datetime64_any_dtype(series):
        return series
    return pd.to_datetime(series, errors="coerce", dayfirst=DATE_DAYFIRST, format="mixed")


def first_present(df, candidates):
    return next((c for c in candidates if c in df.columns), None)


def weighted_rate(data):
    amount = data[AMOUNT_COL].sum()
    if not amount:
        return float('nan')
    return (data[AMOUNT_COL] * data[RATE_COL]).sum() / amount


def metrics(data):
    """(No. of files = count of NEW_CONNO, Lease Amount, WALR)."""
    return (int(data[KEY_COL].notna().sum()), float(data[AMOUNT_COL].sum()), weighted_rate(data))


def format_count(v):
    return "-" if not v else f"{int(v):,}"


def format_amount(v):
    return "-" if pd.isna(v) or v == 0 else f"{v:,.0f}"


def format_rate(v):
    return "-" if pd.isna(v) or v == 0 else f"{v:.2f}"


def ordinal_date(d):
    day = d.day
    suffix = "th" if 11 <= day % 100 <= 13 else {1: "st", 2: "nd", 3: "rd"}.get(day % 10, "th")
    return f"{day}{suffix} {d:%B %Y}"

# ============================================================
# INPUT FILES
# ============================================================

def find_latest(source_key):
    """Newest <prefix>*.xlsx in data/<subdir>/, else in any reports/*/data/ (re-runs)."""
    subdir, prefix = SOURCES[source_key]
    patterns = [DATA_DIR / subdir / f"{prefix}*.xlsx", REPORTS_DIR / "*" / "data" / f"{prefix}*.xlsx"]
    for pattern in patterns:
        files = [Path(f) for f in glob.glob(str(pattern)) if not os.path.basename(f).startswith("~$")]
        if files:
            return max(files, key=os.path.getmtime)
    raise FileNotFoundError(f"No {prefix}*.xlsx found in {DATA_DIR / subdir} or {REPORTS_DIR}/*/data")


def read_report_excel(file_path, key_col):
    """Read an export: header = first row containing key_col; drop footer / Total rows."""
    raw = pd.read_excel(file_path, header=None)
    header_row = None
    for i, row in raw.iterrows():
        cells = row.astype(str).str.strip().str.upper().str.replace(r"\s+", "_", regex=True)
        if key_col in cells.values:
            header_row = i
            break
    if header_row is None:
        raise ValueError(f"Header row with '{key_col}' not found in {file_path}")

    df = pd.read_excel(file_path, header=header_row)
    df.columns = (df.columns.astype(str).str.strip().str.upper()
                  .str.replace(r"\s+", "_", regex=True))
    df = df[_key(df[key_col]).notna()]
    df = df[~df[key_col].astype(str).str.upper().str.contains("TOTAL", na=False)]
    # Footer lines (e.g. 'Generated by ...') have text in the key column only
    df = df[df.drop(columns=[key_col]).notna().any(axis=1)].copy()
    return df


def require_cols(df, cols, label):
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(f"{label}: column(s) {missing} not found. Columns: {list(df.columns)}")

# ============================================================
# CATEGORIZATION
# ============================================================

THREE_WHEELER_PRODUCTS = {"cash in hand", "ijarah small lease", "pledge loan",
                          "three wheeler-lease-brand new", "three wheeler-lease-registered"}
TWO_WHEELER_PRODUCTS = {"2w lease", "ijarah 2w lease"}
AUTO_FINANCE_PRODUCTS = {"diminishing musharaka", "hire purchase-registered",
                         "hire purchase-un-registered", "ijarah lease", "mini truck lease",
                         "murabaha", "other lease", "pledge loan", "vehicle loan-registered",
                         "vehicle loan-un-registered"}
AUTO_FINANCE_ASSETS = {"crew cab", "double cab", "jeep", "mini truck", "motor bus", "motor car",
                       "motor coach", "motor lorry", "motor truck", "motor van", "prime mover",
                       "single cab", "trailer"}


def categorize_product(product_name, asset_descr):
    """Product Category (proudct_categorization.txt section 1)."""
    product, asset = _normalize(product_name), _normalize(asset_descr)
    if product in THREE_WHEELER_PRODUCTS and asset == "three wheeler":
        return "3W"
    if product in TWO_WHEELER_PRODUCTS and asset == "motor cycle":
        return "2W"
    if product in AUTO_FINANCE_PRODUCTS and asset in AUTO_FINANCE_ASSETS:
        return "Auto Finance"
    return "Other"


def categorize_segment(product_name, scheme_description):
    """Product Segment (section 2). First rule that matches wins."""
    scheme, product = _normalize(scheme_description), _normalize(product_name)
    if any(k in scheme for k in SMART_DRAFT_KEYS):
        return "Smart Draft"
    if ENHANCEMENT_RE.search(scheme):
        return "Enhancement"
    if product == "pledge loan":
        return "Pledge Loan"
    if "hire purchase" in product or "lease" in product:
        return "HP/Lease"
    return "Other"

# ============================================================
# DATA PREPARATION
# ============================================================

def load_approvals(files):
    """files: {'HO': path, 'BRANCH': path}. Returns all rows (any status) with APPR_SOURCE."""
    frames = []
    for src, path in files.items():
        d = read_report_excel(path, KEY_COL)
        d["APPR_SOURCE"] = APPR_SOURCE[src]
        log.info(f"Approval Report {APPR_SOURCE[src]}: {len(d):,} rows from {Path(path).name}")
        frames.append(d)
    df = pd.concat(frames, ignore_index=True, sort=False)
    require_cols(df, [STATUS_COL, AMOUNT_COL, RATE_COL, "PRODUCT_NAME", "ASSET_DESCR"],
                 "Approval Report")
    for col in ["SCHEME_DESCRIPTION", CONEX_COL]:
        if col not in df.columns:
            log.warning(f"Approval Report: {col} not found; defaulting to blank.")
            df[col] = pd.NA
    df[AMOUNT_COL] = to_number(df[AMOUNT_COL])
    df[RATE_COL] = to_number(df[RATE_COL]).round(4)
    df[CONEX_COL] = to_date(df[CONEX_COL])
    df["_KEY"] = _key(df[KEY_COL])
    return df


def filter_active(df):
    status = df[STATUS_COL].astype(str).str.strip().str.upper()
    active = df[status == ACTIVE_VALUE].copy()
    log.info(f"{STATUS_COL} = {ACTIVE_VALUE}: {len(active):,} of {len(df):,} rows "
          f"(status counts {status.value_counts().to_dict()})")

    dup = active["_KEY"].duplicated(keep="first")
    if dup.any():
        log.warning(f"{int(dup.sum())} {KEY_COL}(s) appear more than once (HO and Branch?); "
              f"keeping the first: {active.loc[dup, KEY_COL].astype(str).tolist()[:20]}")
        active = active.loc[~dup].copy()
    return active


def map_decision(raw, mapping):
    if pd.isna(raw) or not str(raw).strip():
        return None
    text = " ".join(str(raw).upper().split())
    exact = {k.upper(): v for k, v in mapping.items()}
    if text in exact:
        return exact[text]
    for pattern, decision in DECISION_KEYWORDS:
        if pattern.search(text):
            return decision
    return None


def load_decisions(path, key_col, dec_col, mapping, label):
    """One row per facility: raw decision + mapped decision (None when unmapped)."""
    d = read_report_excel(path, key_col)
    require_cols(d, [key_col, dec_col], label)
    d = d[[key_col, dec_col]].copy()
    d["_KEY"] = _key(d[key_col])
    d["_DEC"] = d[dec_col].map(lambda v: map_decision(v, mapping))
    # Prefer a row with a usable decision; otherwise the last row
    d = (d.assign(_HAS=d["_DEC"].notna()).sort_values("_HAS", kind="stable")
          .drop_duplicates("_KEY", keep="last"))
    log.info(f"{label}: {len(d):,} facilities from {Path(path).name}; "
          f"{dec_col} values {d[dec_col].value_counts(dropna=False).to_dict()}")
    unmapped = d.loc[d["_DEC"].isna() & d[dec_col].notna(), dec_col].astype(str).unique()
    if len(unmapped):
        log.warning(f"{label}: {dec_col} value(s) not mapped to {DECISION_ORDER} "
              f"(treated as not matched): {sorted(unmapped)[:20]} "
              f"-> add them to {'CS' if label.startswith('Credit') else 'RBP'}_DECISION_MAP")
    return d.set_index("_KEY")[[dec_col, "_DEC"]]


def match_decisions(df, cs, rbp):
    """Credit Score first, RBP when Credit Score has no usable decision."""
    df = df.copy()
    keys = df["_KEY"]
    df[f"CS_{CS_DECISION}"] = keys.map(cs[CS_DECISION])
    df["CS_DECISION"] = keys.map(cs["_DEC"])
    df[f"RBP_{RBP_DECISION}"] = keys.map(rbp[RBP_DECISION])
    df["RBP_DECISION"] = keys.map(rbp["_DEC"])

    has_cs, has_rbp = df["CS_DECISION"].notna(), df["RBP_DECISION"].notna()
    same = has_cs & has_rbp & (df["CS_DECISION"] == df["RBP_DECISION"])
    df["DECISION"] = (df["CS_DECISION"].where(has_cs, df["RBP_DECISION"])
                      .fillna(UNMATCHED_DECISION))
    df["DECISION_MATCHED_SRC"] = SRC_NONE
    df.loc[has_rbp, "DECISION_MATCHED_SRC"] = SRC_RBP
    df.loc[has_cs, "DECISION_MATCHED_SRC"] = SRC_CS
    df.loc[same, "DECISION_MATCHED_SRC"] = SRC_BOTH
    df["DECISION_CONFLICT"] = has_cs & has_rbp & ~same

    log.info(f"Decision source: {df['DECISION_MATCHED_SRC'].value_counts().to_dict()}")
    log.info(f"Decision: {df['DECISION'].value_counts().to_dict()}")
    if df["DECISION_CONFLICT"].any():
        log.warning(f"{int(df['DECISION_CONFLICT'].sum())} facility(ies) have different "
              f"decisions in the two reports; Credit Score decision used.")
    return df


def classify_customers(active, history, as_at):
    """
    Existing Customer: the customer has another facility (in `history`) that started
    before this facility's CONEX_DATE and was still active in the
    EXISTING_LOOKBACK_MONTHS before it (no closure date, or closed on/after
    CONEX_DATE - lookback). Otherwise New Customer.
    """
    cust_col = first_present(history, CUSTOMER_ID_CANDIDATES)
    if cust_col is None or cust_col not in active.columns:
        raise ValueError(f"No customer ID column found (looked for {CUSTOMER_ID_CANDIDATES}). "
                         f"Set CUSTOMER_ID_CANDIDATES. Columns: {list(active.columns)}")
    close_col = first_present(history, CLOSURE_CANDIDATES)
    log.info(f"Customer type: customer ID = {cust_col}, closure date = "
          f"{close_col or 'not available (every earlier facility counts as active)'}")

    a = pd.DataFrame({"_KEY": active["_KEY"], "_CUST": _key(active[cust_col]),
                      "_CONEX": active[CONEX_COL].fillna(pd.Timestamp(as_at))})
    h = pd.DataFrame({"_HKEY": history["_KEY"], "_CUST": _key(history[cust_col]),
                      "_HCONEX": history[CONEX_COL],
                      "_HCLOSE": to_date(history[close_col]) if close_col else pd.NaT})
    h = h.dropna(subset=["_CUST", "_HCONEX"]).drop_duplicates("_HKEY")

    m = a.dropna(subset=["_CUST"]).merge(h, on="_CUST")
    window_start = m["_CONEX"] - pd.DateOffset(months=EXISTING_LOOKBACK_MONTHS)
    m = m[(m["_HKEY"] != m["_KEY"]) & (m["_HCONEX"] < m["_CONEX"])
          & (m["_HCLOSE"].isna() | (m["_HCLOSE"] >= window_start))]
    existing = set(m["_KEY"])

    active = active.copy()
    active["CUSTOMER_TYPE"] = active["_KEY"].isin(existing).map(
        {True: "Existing Customers", False: "New Customers"})
    no_id = int(a["_CUST"].isna().sum())
    if no_id:
        log.warning(f"{no_id} facility(ies) without {cust_col}; counted as New Customers.")
    log.info(f"Customer type: {active['CUSTOMER_TYPE'].value_counts().to_dict()}")
    return active


def prepare(files, history_file, as_at):
    allrows = load_approvals({k: files[k] for k in ("HO", "BRANCH")})
    active = filter_active(allrows)

    cs = load_decisions(files["CREDIT_SCORE"], CS_KEY, CS_DECISION, CS_DECISION_MAP,
                        "Credit Score Decision Report")
    rbp = load_decisions(files["RBP"], RBP_KEY, RBP_DECISION, RBP_DECISION_MAP,
                         "RBP Security Approved")
    active = match_decisions(active, cs, rbp)

    active["PRODUCT_CATEGORY"] = [categorize_product(p, a) for p, a in
                                  zip(active["PRODUCT_NAME"], active["ASSET_DESCR"])]
    active["PRODUCT_SEGMENT"] = [categorize_segment(p, s) for p, s in
                                 zip(active["PRODUCT_NAME"], active["SCHEME_DESCRIPTION"])]
    log.info(f"Product Category: {active['PRODUCT_CATEGORY'].value_counts().to_dict()}")

    history = allrows
    if history_file:
        extra = read_report_excel(history_file, KEY_COL)
        if CONEX_COL in extra.columns:
            extra[CONEX_COL] = to_date(extra[CONEX_COL])
        extra["_KEY"] = _key(extra[KEY_COL])
        history = pd.concat([allrows, extra], ignore_index=True, sort=False)
        log.info(f"Customer history: +{len(extra):,} rows from {Path(history_file).name}")
    else:
        log.warning("No --history-file: Existing/New is decided from the downloaded Approval "
              "Reports only, so facilities outside their date range are not seen.")
    active = classify_customers(active, history, as_at)

    target = active[active["PRODUCT_CATEGORY"].isin(PRODUCTS)].copy()
    log.info(f"Product Segment (AF/3W/2W): "
          f"{target.groupby(['PRODUCT_CATEGORY', 'PRODUCT_SEGMENT']).size().to_dict()}")
    return active.drop(columns=["_KEY"]), target.drop(columns=["_KEY"])

# ============================================================
# SUMMARY ROWS (shared by PDF and Excel)
# ============================================================

def segment_label(seg, ctype):
    if seg == "HP/Lease":
        return HP_LEASE_DISPLAY[ctype]
    return SEGMENT_DISPLAY.get(seg, seg)


def segments_for(product, ctype, data):
    base = TEMPLATE_SEGMENTS.get((product, ctype), DEFAULT_TEMPLATE_SEGMENTS)
    present = set(data["PRODUCT_SEGMENT"])
    return [s for s in SEGMENT_ORDER if s in base or s in present]


def summary_rows(product, pdata):
    """
    [(kind, label, decision, (files, amount, walr) | None)]
      type        customer-type heading
      decision    one decision row; label = segment on the first row of the segment
      subtotal    segment total
      type_total  customer-type total
      grand       product total
    """
    rows = []
    for ctype in CUSTOMER_TYPES:
        cdata = pdata[pdata["CUSTOMER_TYPE"] == ctype]
        rows.append(("type", ctype, "", None))
        for seg in segments_for(product, ctype, cdata):
            sdata = cdata[cdata["PRODUCT_SEGMENT"] == seg]
            label = segment_label(seg, ctype)
            for i, dec in enumerate(DECISION_ORDER):
                rows.append(("decision", label if i == 0 else "", dec,
                             metrics(sdata[sdata["DECISION"] == dec])))
            rows.append(("subtotal", f"Total - {label}", "", metrics(sdata)))
        rows.append(("type_total", f"Total - {ctype}", "", metrics(cdata)))
    rows.append(("grand", f"Total - {product}", "", metrics(pdata)))

    files = rows[-1][3][0]
    if files != len(pdata):
        log.warning(f"{product}: table total {files} != {len(pdata)} rows")
    return rows

# ============================================================
# EXCEL OUTPUT  (summary.xlsx layout: B..G, title rows 1-2, header row 3)
# ============================================================

def _fill(hex_color):
    return PatternFill("solid", fgColor=hex_color.lstrip("#"))


def create_excel(target, xlsx_path, as_at, period_text):
    thin = Side(style="thin", color="2F5496")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    hdr_fill, hdr_font = _fill("#4472C4"), Font(bold=True, color="FFFFFF")
    fills = {"type": _fill("#EAF0FA"), "subtotal": _fill("#DEEAF6"),
             "type_total": _fill("#BDD7EE"), "grand": _fill("#BDD7EE")}
    count_fmt, amount_fmt, rate_fmt = '#,##0;-#,##0;"-"', '#,##0;-#,##0;"-"', '0.00;-0.00;"-"'

    wb = Workbook()
    wb.remove(wb.active)
    for product in PRODUCTS:
        ws = wb.create_sheet(product)
        pdata = target[target["PRODUCT_CATEGORY"] == product]
        ws["B1"] = f"{product} (as at {ordinal_date(as_at)})"
        ws["B1"].font = Font(bold=True, size=14, color="1F3864")
        ws["B2"] = period_text
        ws["B2"].font = Font(italic=True, color="2E4C7E")

        headers = ["Customer Type", "Product Segment", "Decision",
                   "No. of files", "Lease Amount (LKR)", "WALR"]
        for i, h in enumerate(headers):
            c = ws.cell(row=3, column=2 + i, value=h)
            c.fill, c.font, c.border = hdr_fill, hdr_font, border
            c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        r = 4
        seg_start = None
        for kind, label, dec, vals in summary_rows(product, pdata):
            cells = [ws.cell(row=r, column=col) for col in range(2, 8)]
            for c in cells:
                c.border = border
            if kind == "type":
                cells[0].value = label
                ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=7)
            elif kind == "decision":
                if label:
                    cells[1].value = label
                    seg_start = r
                cells[2].value = dec
                cells[2].fill = _fill(DECISION_TINT[dec])
                if dec == DECISION_ORDER[-1]:
                    ws.merge_cells(start_row=seg_start, start_column=3, end_row=r, end_column=3)
                    ws.cell(row=seg_start, column=3).alignment = Alignment(vertical="center",
                                                                          wrap_text=True)
            elif kind == "subtotal":
                cells[1].value = label
                ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=4)
            else:                                   # type_total / grand
                cells[0].value = label
                ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=4)

            if vals is not None:
                files, amount, walr = vals
                cells[3].value, cells[3].number_format = files, count_fmt
                cells[4].value, cells[4].number_format = round(amount, 2), amount_fmt
                cells[5].value = None if pd.isna(walr) else round(walr, 4)
                cells[5].number_format = rate_fmt

            if kind in fills:
                start = 1 if kind == "subtotal" else 0
                for c in cells[start:]:
                    c.fill = fills[kind]
                    c.font = Font(bold=True)
            r += 1

        for col, width in zip("ABCDEFG", [2, 22, 26, 11, 12, 20, 10]):
            ws.column_dimensions[col].width = width
        ws.freeze_panes = "B4"

    wb.save(xlsx_path)
    log.info(f"Excel summary saved at: {xlsx_path}")
    return xlsx_path

# ============================================================
# PDF OUTPUT
# ============================================================

def _flow_height(flowable):
    _, h = flowable.wrap(CONTENT_WIDTH, FRAME_HEIGHT)
    return h + flowable.getSpaceBefore() + flowable.getSpaceAfter()


def add_block(elements, lead, table, min_body_rows=5):
    """Keep a table that fits on one page together with its heading."""
    lead_h = sum(_flow_height(f) for f in lead)
    _, table_h = table.wrap(CONTENT_WIDTH, FRAME_HEIGHT)
    if lead_h + table_h <= FRAME_HEIGHT:
        needed = lead_h + table_h
    else:
        needed = lead_h + sum(table._rowHeights[:1 + min_body_rows])
    elements.append(CondPageBreak(needed))
    elements.extend(lead)
    elements.append(table)


BASE_TABLE_STYLE = [
    ('GRID', (0, 0), (-1, -1), 0.5, GRID_COLOR),
    ('BOX', (0, 0), (-1, -1), 1.2, GRID_COLOR),
    ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
    ('FONTSIZE', (0, 0), (-1, -1), 8),
    ('LEADING', (0, 0), (-1, -1), 9.5),
    ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ('TOPPADDING', (0, 0), (-1, -1), 2),
    ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
]


def _product_table(product, pdata):
    hdr = ["Customer Type", "Product Segment", "Decision",
           "No. of files", "Lease Amount (LKR)", "WALR (%)"]
    data = [hdr]
    style = list(BASE_TABLE_STYLE) + [
        ('BACKGROUND', (0, 0), (2, 0), HEADER_BLUE),
        ('BACKGROUND', (3, 0), (-1, 0), SUBHDR_BLUE),
        ('ALIGN', (3, 1), (4, -1), 'RIGHT'),
        ('ALIGN', (5, 1), (5, -1), 'CENTER'),
        ('ALIGN', (2, 1), (2, -1), 'CENTER'),
        ('RIGHTPADDING', (3, 1), (4, -1), 6),
    ]
    seg_start = None
    for kind, label, dec, vals in summary_rows(product, pdata):
        r = len(data)
        values = ["", "", ""] if vals is None else [format_count(vals[0]), format_amount(vals[1]),
                                                     format_rate(vals[2])]
        if kind == "type":
            data.append([label, "", ""] + values)
            style += [('SPAN', (0, r), (-1, r)), ('BACKGROUND', (0, r), (-1, r), LABEL_FILL),
                      ('FONTNAME', (0, r), (-1, r), 'Helvetica-Bold'),
                      ('TEXTCOLOR', (0, r), (-1, r), TABLE_TITLE_BLUE)]
        elif kind == "decision":
            data.append(["", label, dec] + values)
            if label:
                seg_start = r
            style.append(('BACKGROUND', (2, r), (2, r), colors.HexColor(DECISION_TINT[dec])))
            if dec == DECISION_ORDER[-1]:
                style += [('SPAN', (1, seg_start), (1, r)), ('SPAN', (0, seg_start), (0, r))]
        elif kind == "subtotal":
            data.append(["", label, ""] + values)
            style += [('SPAN', (1, r), (2, r)), ('BACKGROUND', (1, r), (-1, r), SUBTOTAL_FILL),
                      ('FONTNAME', (1, r), (-1, r), 'Helvetica-Bold')]
        else:                                           # type_total / grand
            data.append([label, "", ""] + values)
            style += [('SPAN', (0, r), (2, r)), ('BACKGROUND', (0, r), (-1, r), TOTAL_FILL),
                      ('FONTNAME', (0, r), (-1, r), 'Helvetica-Bold')]
            if kind == "grand":
                style.append(('LINEABOVE', (0, r), (-1, r), 1.2, GRID_COLOR))

    widths = [1.5 * inch, 1.9 * inch, 0.8 * inch, 0.9 * inch, 1.5 * inch, 0.8 * inch]
    tbl = Table(data, colWidths=widths, repeatRows=1, hAlign='LEFT')
    tbl.setStyle(TableStyle(style))
    return tbl


def _grouped_table(row_labels, row_filters, target, label_header, value_fn, value_headers,
                   total_label, value_weights=None):
    """Rows x (Auto Finance | 3W | 2W | Total) with value_headers per group."""
    groups = PRODUCTS + ["Total"]
    nv = len(value_headers)
    hdr0 = [label_header] + sum([[g] + [""] * (nv - 1) for g in groups], [])
    hdr1 = [""] + value_headers * len(groups)
    data = [hdr0, hdr1]

    def group_data(g):
        return target if g == "Total" else target[target["PRODUCT_CATEGORY"] == g]

    for label, fn in list(zip(row_labels, row_filters)) + [(total_label, lambda d: d)]:
        row = [label]
        for g in groups:
            row += value_fn(fn(group_data(g)))
        data.append(row)

    total_row = len(data) - 1
    style = list(BASE_TABLE_STYLE) + [
        ('SPAN', (0, 0), (0, 1)),
        ('BACKGROUND', (0, 0), (-1, 1), HEADER_BLUE),
        ('BACKGROUND', (1, 1), (-1, 1), SUBHDR_BLUE),
        ('TEXTCOLOR', (0, 1), (-1, 1), colors.white),
        ('FONTNAME', (0, 1), (-1, 1), 'Helvetica-Bold'),
        ('ALIGN', (0, 1), (-1, 1), 'CENTER'),
        ('FONTSIZE', (0, 1), (-1, 1), 7.5),
        ('ALIGN', (1, 2), (-1, -1), 'RIGHT'),
        ('RIGHTPADDING', (1, 2), (-1, -1), 5),
        ('BACKGROUND', (0, 2), (0, total_row - 1), LABEL_FILL),
        ('FONTNAME', (0, 2), (0, -1), 'Helvetica-Bold'),
        ('BACKGROUND', (0, total_row), (-1, total_row), TOTAL_FILL),
        ('FONTNAME', (0, total_row), (-1, total_row), 'Helvetica-Bold'),
    ]
    for g in range(len(groups)):
        c0 = 1 + g * nv
        style += [('SPAN', (c0, 0), (c0 + nv - 1, 0)),
                  ('LINEAFTER', (c0 + nv - 1, 0), (c0 + nv - 1, -1), 1.0, GRID_COLOR)]
    label_w = 1.8 * inch
    weights = value_weights or [1] * nv
    unit = (CONTENT_WIDTH - label_w) / (len(groups) * sum(weights))
    tbl = Table(data, colWidths=[label_w] + [w * unit for w in weights] * len(groups),
                repeatRows=2, hAlign='LEFT')
    tbl.setStyle(TableStyle(style))
    return tbl


def create_pdf(target, pdf_path, as_at, period_text, source_files):
    log.info(f"Generating PDF at: {pdf_path}")
    doc = SimpleDocTemplate(str(pdf_path), pagesize=PAGE_SIZE,
                            leftMargin=PAGE_MARGIN, rightMargin=PAGE_MARGIN,
                            topMargin=PAGE_MARGIN, bottomMargin=PAGE_MARGIN,
                            title=REPORT_NAME)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle('MainTitle', parent=styles['Title'], fontSize=18, spaceAfter=4,
                                 alignment=TA_CENTER, fontName='Helvetica-Bold',
                                 textColor=TITLE_NAVY)
    table_title_style = ParagraphStyle('TableTitle', parent=styles['Heading2'], fontSize=12,
                                       spaceAfter=4, spaceBefore=6, alignment=TA_LEFT,
                                       fontName='Helvetica-Bold', textColor=TABLE_TITLE_BLUE)
    note_style = ParagraphStyle('Note', parent=styles['Normal'], fontSize=7.5, leading=9,
                                textColor=colors.grey, spaceAfter=3)
    source_style = ParagraphStyle('Source', parent=note_style, alignment=TA_CENTER, spaceAfter=8)

    def heading(text):
        return Paragraph(f"<u>{text}</u>", table_title_style)

    def note(lines):
        return Paragraph("<br/>".join(f"* {l}" for l in lines), note_style)

    elements = [
        Paragraph(REPORT_NAME, title_style),
        Paragraph(f"{period_text} | As at {ordinal_date(as_at)} | "
                  f"Generated: {datetime.now():%Y-%m-%d %H:%M}<br/>"
                  f"Source Files: {', '.join(Path(f).name for f in source_files)}", source_style),
    ]
    common_notes = [
        f"Approved facilities with {STATUS_COL.replace('_', ' ')} = {ACTIVE_VALUE} "
        f"(Approval Report HO + Branch).",
        "No. of files = count of NEW_CONNO; Lease Amount = sum of LEASE AMOUNT; "
        "WALR = Σ(Lease Amount × Int Rate) / Σ Lease Amount.",
    ]

    # 1. Overview
    ov_values = lambda d: [format_count(len(d)), format_amount(d[AMOUNT_COL].sum()),
                           format_rate(weighted_rate(d))]
    tbl = _grouped_table(CUSTOMER_TYPES,
                         [lambda d, c=c: d[d["CUSTOMER_TYPE"] == c] for c in CUSTOMER_TYPES],
                         target, "Customer Type", ov_values,
                         ["No. of files", "Lease Amount", "WALR (%)"], "Total",
                         value_weights=[1, 1.9, 0.9])
    add_block(elements, [heading("1. Overview"), note(common_notes + [
        f"Existing Customer: another facility with CDB that was active within the "
        f"{EXISTING_LOOKBACK_MONTHS} months before the disbursement date (CONEX_DATE)."])], tbl)

    # 2-4. Product tables
    for i, product in enumerate(PRODUCTS, start=2):
        pdata = target[target["PRODUCT_CATEGORY"] == product]
        elements.append(Spacer(1, 8))
        add_block(elements, [heading(f"{i}. {product} (as at {ordinal_date(as_at)})"),
                             note([f"Decision: {CS_DECISION} from the Credit Score Decision "
                                   f"Report; if not matched, {RBP_DECISION} from RBP Security "
                                   f"Approved; not matched in either = {UNMATCHED_DECISION}."])],
                  _product_table(product, pdata))

    # 5. Decision match source
    elements.append(Spacer(1, 8))
    src_values = lambda d: [format_count(len(d)), format_amount(d[AMOUNT_COL].sum())]
    tbl = _grouped_table(SRC_ORDER,
                         [lambda d, s=s: d[d["DECISION_MATCHED_SRC"] == s] for s in SRC_ORDER],
                         target, "Decision Matched Source", src_values,
                         ["No. of files", "Lease Amount"], "Total")
    add_block(elements, [heading(f"{len(PRODUCTS) + 2}. Decision Match Source"),
                         note(["Both = same decision in both reports. "
                               "None = not matched in either report (shown as Manual)."])], tbl)

    doc.build(elements)
    log.info(f"PDF summary saved at: {pdf_path}")
    return pdf_path

# ============================================================
# MAIN
# ============================================================

def move_inputs(files, out_data_dir):
    """Move downloads used for this run from data/ (staging) into reports/<date>/data/."""
    moved = {}
    for key, path in files.items():
        path = Path(path)
        dest = out_data_dir / path.name
        try:
            in_staging = DATA_DIR.resolve() in path.resolve().parents
        except OSError:
            in_staging = False
        if in_staging and path.resolve() != dest.resolve():
            shutil.move(str(path), str(dest))
            moved[key] = dest
            log.info(f"Moved {path.name} -> {dest}")
        else:
            moved[key] = path
            log.info(f"{path.name} not in data/ staging; left in place")
    return moved


def parse_args():
    ap = argparse.ArgumentParser(description=REPORT_NAME)
    ap.add_argument("--mode", choices=MODES, default=os.environ.get("REPORT_MODE", "cumulative"))
    ap.add_argument("--n-months", type=int, default=int(os.environ.get("REPORT_N_MONTHS", "3")),
                    help="months for past-n-months")
    ap.add_argument("--ho-file", help="Approval Report HO (default: latest)")
    ap.add_argument("--branch-file", help="Approval Report Branch (default: latest)")
    ap.add_argument("--cs-file", help="Credit Score Decision Report (default: latest)")
    ap.add_argument("--rbp-file", help="RBP Security Approved (default: latest)")
    ap.add_argument("--history-file",
                    help="optional facility history export (same columns as the Approval "
                         "Report) for the Existing/New customer check")
    ap.add_argument("--no-move", action="store_true",
                    help="leave the input files in data/ (testing)")
    return ap.parse_args()


def log_product_totals(target):
    """One line per product (and total) so each run's figures are in the log."""
    for product in PRODUCTS + ["Total"]:
        d = target if product == "Total" else target[target["PRODUCT_CATEGORY"] == product]
        files, amount, walr = metrics(d)
        by_type = d["CUSTOMER_TYPE"].value_counts().to_dict()
        log.info(f"Summary {product:<12}: files {files:>6,} | lease amount {amount:>18,.2f} | "
                 f"WALR {walr:6.2f} | {by_type}")


def main():
    args = parse_args()
    setup_logging("approved_facility_summary")
    t0 = time.time()
    try:
        start, end = get_period(args.mode, args.n_months)
        label = period_label(start, end)
        mode_text = f"{args.n_months} months" if args.mode == "past-n-months" else args.mode
        period_text = f"Period: {label} ({mode_text})"
        log.info(f"{REPORT_NAME} | mode {args.mode} | {start} to {end}")

        files = {
            "HO": args.ho_file or find_latest("HO"),
            "BRANCH": args.branch_file or find_latest("BRANCH"),
            "CREDIT_SCORE": args.cs_file or find_latest("CREDIT_SCORE"),
            "RBP": args.rbp_file or find_latest("RBP"),
        }
        for k, f in files.items():
            if not os.path.exists(f):
                raise FileNotFoundError(f"{k} file not found: {f}")
            mtime = datetime.fromtimestamp(os.path.getmtime(f)).strftime("%Y-%m-%d %H:%M")
            log.info(f"Input {k:<12}: {Path(f).name} (modified {mtime}, "
                     f"{os.path.getsize(f):,} bytes)")

        active, target = prepare(files, args.history_file, end)
        if target.empty:
            log.warning("No Auto Finance / 3W / 2W facilities in the data; tables will be empty.")
        log_product_totals(target)

        out_dir = REPORTS_DIR / datetime.now().strftime("%Y-%m-%d")
        out_data = out_dir / "data"
        out_data.mkdir(parents=True, exist_ok=True)
        mode_tag = "past-%d-months" % args.n_months if args.mode == "past-n-months" else args.mode
        tag = f"{mode_tag}_{period_tag(start, end)}"

        all_path = out_data / f"Preprocessed_All_{tag}.xlsx"
        target_path = out_data / f"Preprocessed_AF_3W_2W_{tag}.xlsx"
        active.to_excel(all_path, index=False)
        target.to_excel(target_path, index=False)
        log.info(f"Preprocessed data saved to {out_data}: {all_path.name} ({len(active):,} rows), "
                 f"{target_path.name} ({len(target):,} rows)")

        pdf_path = out_dir / f"{REPORT_NAME}_{tag}.pdf"
        xlsx_path = out_dir / f"{REPORT_NAME}_{tag}.xlsx"
        create_pdf(target, pdf_path, end, period_text, files.values())
        create_excel(target, xlsx_path, end, period_text)

        if not args.no_move:
            move_inputs(files, out_data)
        else:
            log.info("--no-move: input files left in place")
        log.info(f"===== {REPORT_NAME} completed in {time.time() - t0:.1f}s =====")

        # Machine-readable lines parsed by main_orchestrator.py
        print(f"RECORDS : {len(target)}")
        print(f"AMOUNT  : {target[AMOUNT_COL].sum():.2f}")
        print(f"PERIOD  : {label}")
        print(f"PDF     : {pdf_path}")
        print(f"EXCEL   : {xlsx_path}")
    except Exception as e:
        log.error(f"Failed to generate {REPORT_NAME}: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
