"""
Shared reporting-period logic for the Approved Facility (AF / 3W / 2W) pipeline.

The mode is read from the REPORT_MODE environment variable (set by
main_orchestrator.py for every child script); past-n-months reads N from
REPORT_N_MONTHS.

  daily         : yesterday
  weekly        : last 7 days, ending yesterday
  cumulative    : 1st of this month to yesterday (on the 1st: the whole previous month)
  monthly       : previous full month
  past-n-months : N full months, ending last month
"""
import os
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta

MODES = ("daily", "weekly", "cumulative", "monthly", "past-n-months")
DEFAULT_MODE = "cumulative"
DEFAULT_N_MONTHS = 3


def get_mode():
    mode = os.environ.get("REPORT_MODE", DEFAULT_MODE).strip().lower()
    if mode not in MODES:
        raise ValueError(f"Unknown REPORT_MODE '{mode}'. Use one of: {', '.join(MODES)}")
    return mode


def get_n_months():
    raw = os.environ.get("REPORT_N_MONTHS", str(DEFAULT_N_MONTHS)).strip()
    n = int(raw)
    if n < 1:
        raise ValueError(f"REPORT_N_MONTHS must be >= 1 (got {raw})")
    return n


def get_period(mode=None, n_months=None, today=None):
    """(start, end) dates, both inclusive."""
    mode = mode or get_mode()
    today = today or date.today()
    yesterday = today - timedelta(days=1)

    if mode == "daily":
        return yesterday, yesterday
    if mode == "weekly":
        return yesterday - timedelta(days=6), yesterday
    if mode == "cumulative":
        return yesterday.replace(day=1), yesterday

    first_this_month = today.replace(day=1)
    n = 1 if mode == "monthly" else (n_months or get_n_months())
    return first_this_month - relativedelta(months=n), first_this_month - timedelta(days=1)


def _is_month_end(d):
    return (d + timedelta(days=1)).day == 1


def period_label(start, end):
    """'12-Nov-2026' | 'October-2026' | 'August-2026 to October-2026' | '01-Nov-2026 to 12-Nov-2026'."""
    if start == end:
        return start.strftime("%d-%b-%Y")
    if start.day == 1 and _is_month_end(end):
        if (start.year, start.month) == (end.year, end.month):
            return start.strftime("%B-%Y")
        return f"{start:%B-%Y} to {end:%B-%Y}"
    return f"{start:%d-%b-%Y} to {end:%d-%b-%Y}"


def period_tag(start, end):
    """File-name-safe version of period_label."""
    return period_label(start, end).replace(" ", "_")
