"""
Email for the Approved Facility (AF / 3W / 2W) Analysis.

Used by main_orchestrator.py, or on its own to (re)send the latest report
from reports/<YYYY-MM-DD>/:

    python email_config.py --mode cumulative
    python email_config.py --mode past-n-months --n-months 3 --date 2026-11-13
    python email_config.py --mode daily --dry-run          # show what would be sent

credentials.env:
    SMTP_SERVER, SMTP_PORT (25), SMTP_USE_TLS (false), SMTP_USERNAME, SMTP_PASSWORD, EMAIL_FROM
    APPR_AF_TO, APPR_AF_CC              comma/semicolon separated
    APPR_AF_TO_<MODE>, APPR_AF_CC_<MODE> optional per-mode override
                                        (MODE = DAILY, WEEKLY, CUMULATIVE, MONTHLY, PAST_N_MONTHS)
    APPR_AF_ERROR_TO                    optional, failure alerts
"""
import os
import sys
import glob
import argparse
import logging
import smtplib
from pathlib import Path
from datetime import datetime
from email.message import EmailMessage

from dotenv import load_dotenv

from report_period import MODES, get_period, period_label, period_tag
from log_config import setup_logging

# Module logger; handlers are set up by the caller (orchestrator) or in main()
log = logging.getLogger("email_config")

BASE_DIR = Path(__file__).resolve().parent
REPORTS_DIR = BASE_DIR / "reports"
load_dotenv(BASE_DIR / "credentials.env")

from approved_facility_summary import REPORT_NAME  # noqa: E402  (single place for the name)

TO_VAR, CC_VAR, ERROR_TO_VAR = "APPR_AF_TO", "APPR_AF_CC", "APPR_AF_ERROR_TO"

# ============================================================
# RECIPIENTS / SMTP
# ============================================================

def _split(raw):
    return [a.strip() for a in (raw or "").replace(";", ",").split(",") if a.strip()]


def recipients(var, mode=None):
    """<VAR>_<MODE> if set (e.g. APPR_AF_TO_DAILY), else <VAR>."""
    if mode:
        override = os.environ.get(f"{var}_{mode.upper().replace('-', '_')}")
        if override:
            return _split(override)
    return _split(os.environ.get(var))


def send_email(subject, html, to, cc=None, attachments=()):
    server = os.environ.get("SMTP_SERVER")
    sender = os.environ.get("EMAIL_FROM")
    if not server or not sender:
        raise EnvironmentError("SMTP_SERVER and EMAIL_FROM must be set in credentials.env")
    if not to:
        raise EnvironmentError(f"No recipients ({TO_VAR}) set in credentials.env")

    msg = EmailMessage()
    msg["Subject"], msg["From"], msg["To"] = subject, sender, ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg.set_content("This email requires an HTML-capable mail client.")
    msg.add_alternative(html, subtype="html")
    for path in attachments:
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Attachment not found: {path}")
        subtype = ("pdf" if path.suffix.lower() == ".pdf"
                   else "vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        msg.add_attachment(path.read_bytes(), maintype="application", subtype=subtype,
                           filename=path.name)
        log.info(f"Attached {path.name} ({path.stat().st_size:,} bytes)")

    port = int(os.environ.get("SMTP_PORT", "25"))
    use_tls = os.environ.get("SMTP_USE_TLS", "false").lower() in ("1", "true", "yes")
    log.info(f"Connecting to SMTP {server}:{port} (TLS {'on' if use_tls else 'off'}) as {sender}")
    with smtplib.SMTP(server, port, timeout=60) as smtp:
        if use_tls:
            smtp.starttls()
        user, pwd = os.environ.get("SMTP_USERNAME"), os.environ.get("SMTP_PASSWORD")
        if user and pwd:
            smtp.login(user, pwd)
            log.info(f"SMTP login OK ({user})")
        smtp.send_message(msg)          # To + Cc taken from the headers
    log.info(f"Sent '{subject}' | To: {', '.join(to)} | Cc: {', '.join(cc or []) or '-'}")

# ============================================================
# MESSAGES
# ============================================================

def report_message(period, mode_text, records=None, amount=None):
    subject = f"{REPORT_NAME} - {period}"
    stats = ""
    if records is not None and amount is not None:
        stats = (f"<p>Approved facilities (AF, 3W &amp; 2W): <b>{int(float(records)):,}</b> "
                 f"| Lease Amount: <b>LKR {float(amount):,.0f}</b></p>")
    html = f"""
    <p>Dear All,</p>
    <p>Please find attached the <b>{REPORT_NAME}</b> for <b>{period}</b> ({mode_text}).</p>
    {stats}
    <p>This is an automated email.</p>"""
    return subject, html


def send_report(pdf, excel, period, mode, mode_text, records=None, amount=None, dry_run=False):
    subject, html = report_message(period, mode_text, records, amount)
    to, cc = recipients(TO_VAR, mode), recipients(CC_VAR, mode)
    if dry_run:
        log.info(f"[DRY-RUN] Subject: {subject}")
        log.info(f"[DRY-RUN] To: {to or '(none - set ' + TO_VAR + ')'}")
        log.info(f"[DRY-RUN] Cc: {cc or '-'}")
        log.info(f"[DRY-RUN] Attachments: {Path(pdf).name}, {Path(excel).name}")
        return
    send_email(subject, html, to, cc, attachments=[pdf, excel])


def send_failure(step, mode_text):
    """Failure alert to APPR_AF_ERROR_TO (skipped if not set). Never raises."""
    to = recipients(ERROR_TO_VAR)
    if not to:
        log.info(f"{ERROR_TO_VAR} not set; no failure email sent")
        return
    log.info(f"Sending failure alert for step '{step}'")
    subject = f"[FAILED] {REPORT_NAME} - {step}"
    html = (f"<p>The {REPORT_NAME} run ({mode_text}) failed at <b>{step}</b>. "
            f"Check the orchestrator log on the automation machine.</p>")
    try:
        send_email(subject, html, to)
    except Exception as e:
        log.warning(f"Could not send failure email: {e}")

# ============================================================
# STANDALONE: send the latest report in reports/<date>/
# ============================================================

def mode_tag(mode, n_months):
    return f"past-{n_months}-months" if mode == "past-n-months" else mode


def latest_outputs(mode, n_months, run_date):
    """Newest PDF + Excel for this mode/period in reports/<run_date>/."""
    start, end = get_period(mode, n_months)
    stem = f"{REPORT_NAME}_{mode_tag(mode, n_months)}_{period_tag(start, end)}"
    folder = REPORTS_DIR / run_date
    found = {}
    for ext in (".pdf", ".xlsx"):
        files = [Path(f) for f in glob.glob(glob.escape(str(folder / stem)) + ext)]
        if not files:
            raise FileNotFoundError(f"{stem}{ext} not found in {folder}")
        found[ext] = max(files, key=os.path.getmtime)
    return found[".pdf"], found[".xlsx"], period_label(start, end)


def main():
    ap = argparse.ArgumentParser(description=f"Email the {REPORT_NAME}")
    ap.add_argument("--mode", choices=MODES, default="cumulative")
    ap.add_argument("--n-months", type=int, default=3)
    ap.add_argument("--date", default=datetime.now().strftime("%Y-%m-%d"),
                    help="run date folder reports/<YYYY-MM-DD> (default: today)")
    ap.add_argument("--dry-run", action="store_true", help="print, do not send")
    args = ap.parse_args()
    setup_logging("email_config")
    try:
        pdf, excel, period = latest_outputs(args.mode, args.n_months, args.date)
        log.info(f"Latest outputs in reports/{args.date}: {pdf.name}, {excel.name}")
        mode_text = f"{args.n_months} months" if args.mode == "past-n-months" else args.mode
        send_report(pdf, excel, period, args.mode, mode_text, dry_run=args.dry_run)
    except Exception as e:
        log.error(f"Email failed: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
