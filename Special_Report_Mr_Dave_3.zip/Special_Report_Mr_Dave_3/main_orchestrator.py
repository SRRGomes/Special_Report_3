"""
Orchestrator — Approved Facility (AF / 3W / 2W) Analysis.

    python main_orchestrator.py --mode cumulative
    python main_orchestrator.py --mode past-n-months --n-months 3
    python main_orchestrator.py --mode daily --skip-download --no-emails      # testing

Steps:
  1. Download Approval Report HO + Branch (Oracle BI) and the Credit Score Decision /
     RBP Security Approved reports (SmartOps ERP)            [skipped by --skip-download]
  2. approved_facility_summary.py -> PDF + Excel in reports/<YYYY-MM-DD>/
  3. Email the PDF + Excel via email_config.py              [skipped by --no-emails]

Exit code 0 on success, 1 on failure.
"""
import os
import sys
import argparse
import logging
import subprocess
import time
from pathlib import Path

from dotenv import load_dotenv

from report_period import MODES, get_period, period_label
from log_config import log_file_path, setup_logging

log = logging.getLogger("main_orchestrator")

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / "credentials.env")

from approved_facility_summary import REPORT_NAME  # noqa: E402  (single place for the name)
from email_config import send_failure, send_report  # noqa: E402

DOWNLOAD_STEPS = [
    ("Approval Report HO", ["approval_report_data.py", "--type", "HO"]),
    ("Approval Report Branch", ["approval_report_data.py", "--type", "BRANCHES"]),
    ("Credit Score Decision Report", ["erp_decision_report_data.py", "--report", "credit-score"]),
    ("RBP Security Approved", ["erp_decision_report_data.py", "--report", "rbp"]),
]
SUMMARY_SCRIPT = "approved_facility_summary.py"


STEP_TIMES = []          # (step, status, seconds) for the end-of-run summary


def run_step(name, args, env):
    """
    Run a child script, echo its output to the console, return (exit code, output lines).
    Child scripts write their own lines to the same daily log file, so their output is
    echoed (print) rather than logged again.
    """
    log.info(f"----- STEP: {name} | {' '.join(args)} -----")
    t0 = time.time()
    proc = subprocess.Popen([sys.executable, str(BASE_DIR / args[0]), *args[1:]],
                            cwd=BASE_DIR, env=env, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, encoding="utf-8",
                            errors="replace")
    lines = []
    for line in proc.stdout:
        print(line, end="", flush=True)
        lines.append(line.rstrip("\n"))
    proc.wait()
    secs = time.time() - t0
    status = "OK" if proc.returncode == 0 else f"FAILED (exit {proc.returncode})"
    STEP_TIMES.append((name, status, secs))
    (log.info if proc.returncode == 0 else log.error)(f"STEP {name}: {status} in {secs:.0f}s")
    return proc.returncode, lines


def parse_outputs(lines):
    out = {}
    for line in lines:
        for key in ("RECORDS", "AMOUNT", "PERIOD", "PDF", "EXCEL"):
            if line.startswith(key) and ":" in line:
                out[key] = line.split(":", 1)[1].strip()
    return out


# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description=f"{REPORT_NAME} orchestrator")
    ap.add_argument("--mode", choices=MODES, default="cumulative")
    ap.add_argument("--n-months", type=int, default=3, help="months for past-n-months")
    ap.add_argument("--skip-download", action="store_true",
                    help="testing: use the latest files already downloaded")
    ap.add_argument("--no-emails", action="store_true", help="testing: do not send emails")
    ap.add_argument("--history-file", help="passed to the summary (Existing/New check)")
    args = ap.parse_args()
    setup_logging("main_orchestrator")
    run_start = time.time()

    mode_text = f"{args.n_months} months" if args.mode == "past-n-months" else args.mode
    start, end = get_period(args.mode, args.n_months)
    log.info(f"{REPORT_NAME} | mode {mode_text} | {period_label(start, end)} "
             f"({start} to {end}) | skip-download={args.skip_download} "
             f"| no-emails={args.no_emails}")

    env = dict(os.environ, REPORT_MODE=args.mode, REPORT_N_MONTHS=str(args.n_months),
               PYTHONIOENCODING="utf-8")

    if not args.skip_download:
        for name, step in DOWNLOAD_STEPS:
            code, _ = run_step(name, step, env)
            if code != 0:
                log.error(f"{name} download failed; stopping. "
                          f"See {log_file_path().name} and the report_fail_*.png screenshots.")
                if not args.no_emails:
                    send_failure(name, mode_text)
                log_run_summary(run_start, ok=False)
                sys.exit(1)
    else:
        log.info("--skip-download: using the latest downloaded files.")

    summary_args = [SUMMARY_SCRIPT, "--mode", args.mode, "--n-months", str(args.n_months)]
    if args.history_file:
        summary_args += ["--history-file", args.history_file]
    code, lines = run_step("Summary (PDF + Excel)", summary_args, env)
    outputs = parse_outputs(lines)
    if code != 0 or "PDF" not in outputs or "EXCEL" not in outputs:
        log.error("Summary step failed (no PDF/EXCEL in its output); no email sent.")
        if not args.no_emails:
            send_failure("Summary", mode_text)
        log_run_summary(run_start, ok=False)
        sys.exit(1)
    log.info(f"Summary: {outputs.get('RECORDS')} AF/3W/2W facilities, "
             f"LKR {float(outputs.get('AMOUNT', 0)):,.0f} | period {outputs.get('PERIOD')}")

    if args.no_emails:
        log.info("--no-emails: email skipped.")
    else:
        log.info("Sending report email")
        try:
            send_report(outputs["PDF"], outputs["EXCEL"], outputs.get("PERIOD", ""),
                        args.mode, mode_text, outputs.get("RECORDS"), outputs.get("AMOUNT"))
        except Exception as e:
            log.error(f"Email failed: {e}", exc_info=True)
            log_run_summary(run_start, ok=False)
            sys.exit(1)

    log.info(f"PDF  : {outputs['PDF']}")
    log.info(f"Excel: {outputs['EXCEL']}")
    log_run_summary(run_start, ok=True)
    sys.exit(0)


def log_run_summary(run_start, ok):
    for name, status, secs in STEP_TIMES:
        log.info(f"  {name:<32} {status:<20} {secs:>6.0f}s")
    (log.info if ok else log.error)(
        f"===== {REPORT_NAME} run {'COMPLETED' if ok else 'FAILED'} in "
        f"{time.time() - run_start:.0f}s | log: {log_file_path()} =====")


if __name__ == "__main__":
    main()
